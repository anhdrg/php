<?php
// /views/product-list.php
// Dữ liệu $data, $page_title,... đã được controller chuẩn bị

// Nếu bạn muốn product-list.php sử dụng cùng một layout và logic như index.php,
// chỉ cần include file đó.
// Controller đã đặt biến $data['is_product_list_page'] = true;
// để index.php có thể nhận biết và thay đổi tiêu đề nếu cần.

require_once __DIR__ . '/index.php';
?>
